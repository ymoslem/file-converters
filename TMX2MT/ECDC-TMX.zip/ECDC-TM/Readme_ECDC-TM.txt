European Commission - Joint Research Centre (JRC)
Ralf Steinberger
16.03.2016

This zip file contains the ECDC Translation Memory ECDC-TM.
ECDC-TM consists of translation units in 25 languages.
For details, go to https://ec.europa.eu/jrc/en/language-technologies/ecdc-translation-memory .

