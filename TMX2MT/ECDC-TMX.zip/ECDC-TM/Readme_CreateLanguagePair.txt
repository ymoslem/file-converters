﻿Author: Mohamed Ebrahim
Date:   19 October 2012

CreateLanguaePair is a command-line tool that allows users to extract - out of the large multilingual ECDC Translation-Memory file - a translation memory file containing only one language pair of your choice. 

In order to use this tool you need to install java version 6 or higher. 


Usage:

Java -jar CreateLanguagePair.jar  -fl First_Language -i Input_File -o Output_File -sl Second_Language

First_Language: is the first language you want to have in the language pair.
Second_language: is the second language you want to have in the language pair.
Input_File: is the main translation memory you want to extract the language pair from, i.e. ECDC.tmx.
Output_File: is the name of the file with the results of the extraction, e.g. en-de.tmx.

When selecting the languages, you need to use the two-letter ISO codes, e.g. en for English, de for German, el for Greek, etc.

Have Fun!
